<?php
/*********** DB CONNECTION  *****************/
define("DB_HOST","localhost");
define("DB_USER","root");
define("DB_PWD","");
define("DB_NAME","resumedb");
/***********  END  ****************/

/*********** OTHERS *****************/
define("SITE_URL", "");
define("SITE_NAME", "");
/*define();
  define();*/
/***********        ****************/


?>